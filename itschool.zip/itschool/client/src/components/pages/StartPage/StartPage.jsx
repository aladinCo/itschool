import React from 'react';
const StartPage = () => {
    return(
        <>
            Start Page
        </>
    )
}

export default StartPage;